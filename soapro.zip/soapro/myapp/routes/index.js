var express = require('express');
var router = express.Router();
const db = require('../database/database')

/* GET home page. */
router.get('/',async function(req, res, next) {
  const result = await db.getHome();
  const result2 = await db.getHome2();
  const result3 = await db.getHome3();
  const result4 = await db.getMap();

  console.log(result.rows);
  res.render('index', { resultData: result.rows,resultData2: result2.rows,resultData3: result3.rows,mapData: result4.rows });
});

router.get('/table',async function(req, res, next) {
  const result = await db.gettable();

  console.log(result.rows);
  res.render('table', { resultData: result.rows});
});

router.get('/graph',async function(req, res, next) {
  const result = await db.gatPort();

  console.log(result.rows);
  res.render('graph', { resultData: result.rows});
});
module.exports = router;
